﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Git.Constants
{
    public class RedirectConst
    {
        public const string AllRepositories = "/Repositories/All";
        public const string LoginPage = "/Users/Login";
    }
}
